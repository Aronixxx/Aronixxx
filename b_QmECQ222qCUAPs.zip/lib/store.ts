import { create } from 'zustand'
import { persist } from 'zustand/middleware'

export interface EmailAccount {
  id: string
  email: string
  password: string
  provider: string
  phone?: string
  recoveryEmail?: string
  notes?: string
  image?: string
  tags: string[]
  createdAt: string
  updatedAt: string
}

export interface PublishedApp {
  id: string
  name: string
  description: string
  details: string
  version: string
  downloadLink: string
  apkLink: string
  websiteLink: string
  screenshots: string[]
  loginImage: string
  icon: string
  category: string
  createdAt: string
  updatedAt: string
}

export interface SharedLink {
  id: string
  password: string
  expiresAt: string | null
  isActive: boolean
  createdAt: string
  accessCount: number
}

export interface AppSettings {
  appName: string
  splashDuration: number
  showSplash: boolean
  defaultProvider: string
  accentColor: string
  appPassword: string | null
  isLocked: boolean
  sharedLinks: SharedLink[]
}

interface EmailStore {
  accounts: EmailAccount[]
  publishedApps: PublishedApp[]
  settings: AppSettings
  selectedIds: string[]
  searchQuery: string
  filterProvider: string
  
  // Account actions
  addAccount: (account: Omit<EmailAccount, 'id' | 'createdAt' | 'updatedAt'>) => void
  updateAccount: (id: string, data: Partial<EmailAccount>) => void
  deleteAccount: (id: string) => void
  deleteSelected: () => void
  deleteAll: () => void
  
  // Selection actions
  toggleSelect: (id: string) => void
  selectAll: () => void
  selectOne: (id: string) => void
  clearSelection: () => void
  
  // Filter actions
  setSearchQuery: (query: string) => void
  setFilterProvider: (provider: string) => void
  
  // Settings actions
  updateSettings: (settings: Partial<AppSettings>) => void
  setAppPassword: (password: string | null) => void
  unlockApp: () => void
  lockApp: () => void
  
  // Import/Export
  importAccounts: (accounts: EmailAccount[]) => void
  exportAccounts: () => EmailAccount[]
  exportSelected: () => EmailAccount[]
  
  // Published Apps
  addPublishedApp: (app: Omit<PublishedApp, 'id' | 'createdAt' | 'updatedAt'>) => void
  updatePublishedApp: (id: string, data: Partial<PublishedApp>) => void
  deletePublishedApp: (id: string) => void
}

const generateId = () => Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15)

export const useEmailStore = create<EmailStore>()(
  persist(
    (set, get) => ({
      accounts: [],
      publishedApps: [],
      settings: {
        appName: 'GymMail Vault',
        splashDuration: 3000,
        showSplash: true,
        defaultProvider: 'Gmail',
        accentColor: 'green',
        appPassword: null,
        isLocked: true,
        sharedLinks: [],
      },
      selectedIds: [],
      searchQuery: '',
      filterProvider: 'all',

      addAccount: (account) => set((state) => ({
        accounts: [
          ...state.accounts,
          {
            ...account,
            id: generateId(),
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
          },
        ],
      })),

      updateAccount: (id, data) => set((state) => ({
        accounts: state.accounts.map((acc) =>
          acc.id === id
            ? { ...acc, ...data, updatedAt: new Date().toISOString() }
            : acc
        ),
      })),

      deleteAccount: (id) => set((state) => ({
        accounts: state.accounts.filter((acc) => acc.id !== id),
        selectedIds: state.selectedIds.filter((sid) => sid !== id),
      })),

      deleteSelected: () => set((state) => ({
        accounts: state.accounts.filter((acc) => !state.selectedIds.includes(acc.id)),
        selectedIds: [],
      })),

      deleteAll: () => set({ accounts: [], selectedIds: [] }),

      toggleSelect: (id) => set((state) => ({
        selectedIds: state.selectedIds.includes(id)
          ? state.selectedIds.filter((sid) => sid !== id)
          : [...state.selectedIds, id],
      })),

      selectAll: () => set((state) => ({
        selectedIds: state.accounts.map((acc) => acc.id),
      })),

      selectOne: (id) => set(() => ({
        selectedIds: [id],
      })),

      clearSelection: () => set({ selectedIds: [] }),

      setSearchQuery: (query) => set({ searchQuery: query }),
      setFilterProvider: (provider) => set({ filterProvider: provider }),

      updateSettings: (settings) => set((state) => ({
        settings: { ...state.settings, ...settings },
      })),

      setAppPassword: (password) => set((state) => ({
        settings: { ...state.settings, appPassword: password, isLocked: password ? true : false },
      })),

      unlockApp: () => set((state) => ({
        settings: { ...state.settings, isLocked: false },
      })),

      lockApp: () => set((state) => ({
        settings: { ...state.settings, isLocked: state.settings.appPassword ? true : false },
      })),

      importAccounts: (accounts) => set((state) => ({
        accounts: [
          ...state.accounts,
          ...accounts.map((acc) => ({
            ...acc,
            id: generateId(),
            createdAt: acc.createdAt || new Date().toISOString(),
            updatedAt: new Date().toISOString(),
          })),
        ],
      })),

      exportAccounts: () => get().accounts,
      
      exportSelected: () => {
        const state = get()
        return state.accounts.filter(acc => state.selectedIds.includes(acc.id))
      },

      // Published Apps
      addPublishedApp: (app) => set((state) => ({
        publishedApps: [
          ...state.publishedApps,
          {
            ...app,
            id: generateId(),
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
          },
        ],
      })),

      updatePublishedApp: (id, data) => set((state) => ({
        publishedApps: state.publishedApps.map((app) =>
          app.id === id
            ? { ...app, ...data, updatedAt: new Date().toISOString() }
            : app
        ),
      })),

      deletePublishedApp: (id) => set((state) => ({
        publishedApps: state.publishedApps.filter((app) => app.id !== id),
      })),
    }),
    {
      name: 'gymmail-vault-storage',
    }
  )
)

// Provider options
export const EMAIL_PROVIDERS = [
  'Gmail',
  'Hotmail',
  'Outlook',
  'Yahoo',
  'iCloud',
  'ProtonMail',
  'AOL',
  'Zoho',
  'Otro',
]

// Tag suggestions
export const TAG_SUGGESTIONS = [
  'Personal',
  'Trabajo',
  'Negocios',
  'Redes Sociales',
  'Compras',
  'Bancario',
  'Juegos',
  'Streaming',
  'Viajes',
  'Educacion',
]

// App Categories
export const APP_CATEGORIES = [
  'Fitness',
  'Productividad',
  'Redes Sociales',
  'Entretenimiento',
  'Finanzas',
  'Educacion',
  'Salud',
  'Juegos',
  'Utilidades',
  'Otro',
]

// Export Templates - 1000 plantillas organizadas por categorias
export const EXPORT_TEMPLATES = {
  profesional: [
    { id: 'prof-1', name: 'Corporativo Elegante', description: 'Diseno ejecutivo con colores sobrios', colors: ['#1a1a2e', '#16213e', '#0f3460', '#e94560'] },
    { id: 'prof-2', name: 'Minimalista Pro', description: 'Limpio y profesional', colors: ['#ffffff', '#f8f9fa', '#212529', '#0d6efd'] },
    { id: 'prof-3', name: 'Business Dark', description: 'Tema oscuro empresarial', colors: ['#0d1117', '#161b22', '#21262d', '#58a6ff'] },
    { id: 'prof-4', name: 'Legal Standard', description: 'Para documentos legales', colors: ['#ffffff', '#f5f5f5', '#1a1a1a', '#8b0000'] },
    { id: 'prof-5', name: 'Finanzas Gold', description: 'Estilo bancario dorado', colors: ['#0a0a0a', '#1a1a1a', '#d4af37', '#f4e4bc'] },
  ],
  gym: [
    { id: 'gym-1', name: 'Power Green', description: 'Verde neon energetico', colors: ['#0a0a0a', '#1a1a1a', '#00ff41', '#39ff14'] },
    { id: 'gym-2', name: 'Beast Mode Red', description: 'Rojo intenso de poder', colors: ['#0d0d0d', '#1f1f1f', '#ff0000', '#ff4444'] },
    { id: 'gym-3', name: 'Iron Blue', description: 'Azul acero muscular', colors: ['#0a0e17', '#141c2f', '#00d4ff', '#0099cc'] },
    { id: 'gym-4', name: 'Protein Orange', description: 'Naranja energizante', colors: ['#1a0a00', '#2d1a0a', '#ff6b00', '#ff9500'] },
    { id: 'gym-5', name: 'Flex Purple', description: 'Purpura deportivo', colors: ['#0d0a17', '#1a142f', '#9933ff', '#cc66ff'] },
    { id: 'gym-6', name: 'CrossFit Yellow', description: 'Amarillo de alta intensidad', colors: ['#1a1a00', '#2d2d0a', '#ffff00', '#cccc00'] },
    { id: 'gym-7', name: 'Cardio Pink', description: 'Rosa fitness vibrante', colors: ['#170a10', '#2f141c', '#ff1493', '#ff69b4'] },
    { id: 'gym-8', name: 'Strength Black', description: 'Negro potente con detalles', colors: ['#000000', '#111111', '#ffffff', '#888888'] },
    { id: 'gym-9', name: 'Neon Mix', description: 'Combinacion de neons', colors: ['#0a0a0a', '#1a1a1a', '#00ff41', '#ff00ff'] },
    { id: 'gym-10', name: 'Titan Gold', description: 'Dorado de campeon', colors: ['#0a0a0a', '#1a1507', '#ffd700', '#ffaa00'] },
  ],
  tech: [
    { id: 'tech-1', name: 'Matrix Code', description: 'Estilo hacker verde', colors: ['#000000', '#0d1a0d', '#00ff00', '#003300'] },
    { id: 'tech-2', name: 'Cyberpunk', description: 'Futurista neon', colors: ['#0a0a1a', '#1a1a3f', '#ff00ff', '#00ffff'] },
    { id: 'tech-3', name: 'Terminal Dark', description: 'Consola de comandos', colors: ['#1e1e1e', '#252526', '#569cd6', '#4ec9b0'] },
    { id: 'tech-4', name: 'AI Neural', description: 'Inteligencia artificial', colors: ['#0d0d1a', '#1a1a2f', '#6366f1', '#8b5cf6'] },
    { id: 'tech-5', name: 'Blockchain', description: 'Cripto moderno', colors: ['#0a0a14', '#141428', '#f7931a', '#627eea'] },
  ],
  naturaleza: [
    { id: 'nat-1', name: 'Forest', description: 'Bosque sereno', colors: ['#0d1f0d', '#1a3a1a', '#228b22', '#90ee90'] },
    { id: 'nat-2', name: 'Ocean', description: 'Oceano profundo', colors: ['#001f3f', '#003366', '#0077be', '#87ceeb'] },
    { id: 'nat-3', name: 'Sunset', description: 'Atardecer calido', colors: ['#1a0a00', '#4a1a00', '#ff6347', '#ffa07a'] },
    { id: 'nat-4', name: 'Aurora', description: 'Aurora boreal', colors: ['#0a0d17', '#0d1a2f', '#00ff87', '#87ceeb'] },
    { id: 'nat-5', name: 'Desert', description: 'Desierto caliente', colors: ['#1f1a0d', '#3a2f1a', '#daa520', '#f4a460'] },
  ],
  gaming: [
    { id: 'game-1', name: 'RGB Gamer', description: 'Colores RGB vibrantes', colors: ['#0a0a0a', '#1a1a1a', '#ff0000', '#00ff00'] },
    { id: 'game-2', name: 'Retro Arcade', description: 'Estilo 8-bit clasico', colors: ['#000000', '#1a1a2e', '#e94560', '#00ff00'] },
    { id: 'game-3', name: 'Esports', description: 'Competitivo profesional', colors: ['#0d0d1a', '#1a1a3f', '#ff4444', '#00ccff'] },
    { id: 'game-4', name: 'RPG Fantasy', description: 'Fantasia epica', colors: ['#1a0d1a', '#2f1a2f', '#9933ff', '#ff9933'] },
    { id: 'game-5', name: 'FPS Tactical', description: 'Tactico militar', colors: ['#0d0d0a', '#1a1a14', '#556b2f', '#ffa500'] },
  ],
  social: [
    { id: 'soc-1', name: 'Instagram', description: 'Gradiente Instagram', colors: ['#833ab4', '#fd1d1d', '#fcb045', '#ffffff'] },
    { id: 'soc-2', name: 'Twitter/X', description: 'Estilo Twitter', colors: ['#15202b', '#192734', '#1da1f2', '#ffffff'] },
    { id: 'soc-3', name: 'LinkedIn', description: 'Profesional LinkedIn', colors: ['#0a66c2', '#004182', '#ffffff', '#000000'] },
    { id: 'soc-4', name: 'TikTok', description: 'Vibrante TikTok', colors: ['#010101', '#161823', '#ff0050', '#00f2ea'] },
    { id: 'soc-5', name: 'Discord', description: 'Comunidad Discord', colors: ['#36393f', '#2f3136', '#5865f2', '#ffffff'] },
  ],
  elegante: [
    { id: 'eleg-1', name: 'Luxury Black', description: 'Negro de lujo', colors: ['#000000', '#1a1a1a', '#c9a227', '#ffffff'] },
    { id: 'eleg-2', name: 'Rose Gold', description: 'Oro rosa sofisticado', colors: ['#1a0d0d', '#2f1a1a', '#b76e79', '#f4c2c2'] },
    { id: 'eleg-3', name: 'Platinum', description: 'Platino premium', colors: ['#e5e4e2', '#c0c0c0', '#1a1a1a', '#4a4a4a'] },
    { id: 'eleg-4', name: 'Emerald', description: 'Esmeralda real', colors: ['#0d1a0d', '#1a2f1a', '#50c878', '#00a86b'] },
    { id: 'eleg-5', name: 'Sapphire', description: 'Zafiro profundo', colors: ['#0d0d1a', '#1a1a3f', '#0f52ba', '#6593f5'] },
  ],
  estacional: [
    { id: 'season-1', name: 'Primavera', description: 'Flores y vida', colors: ['#fff5f5', '#ffe4e6', '#ec4899', '#22c55e'] },
    { id: 'season-2', name: 'Verano', description: 'Sol y playa', colors: ['#fffbeb', '#fef3c7', '#f59e0b', '#06b6d4'] },
    { id: 'season-3', name: 'Otono', description: 'Hojas y calidez', colors: ['#1a0d00', '#2f1a00', '#d97706', '#92400e'] },
    { id: 'season-4', name: 'Invierno', description: 'Nieve y frio', colors: ['#f0f9ff', '#e0f2fe', '#0ea5e9', '#1e3a5f'] },
    { id: 'season-5', name: 'Halloween', description: 'Terrorificamente divertido', colors: ['#0d0d0d', '#1a0d00', '#ff6600', '#800080'] },
    { id: 'season-6', name: 'Navidad', description: 'Festivo tradicional', colors: ['#0d1a0d', '#1a0d0d', '#ff0000', '#00ff00'] },
  ],
}

// Generar mas plantillas programaticamente para llegar a 1000
export const generateTemplates = () => {
  const baseTemplates = Object.values(EXPORT_TEMPLATES).flat()
  const allTemplates = [...baseTemplates]
  
  const variations = ['Light', 'Dark', 'Neon', 'Pastel', 'Vibrant', 'Muted', 'Bold', 'Soft', 'Gradient', 'Mono']
  const categories = ['Fitness', 'Sport', 'Workout', 'Training', 'Cardio', 'Strength', 'Power', 'Energy', 'Health', 'Wellness']
  
  let counter = baseTemplates.length
  
  while (allTemplates.length < 1000) {
    const variation = variations[counter % variations.length]
    const category = categories[Math.floor(counter / variations.length) % categories.length]
    
    const hue = (counter * 37) % 360
    const baseColor = `hsl(${hue}, 70%, 50%)`
    const darkColor = `hsl(${hue}, 70%, 10%)`
    const lightColor = `hsl(${hue}, 70%, 90%)`
    const accentHue = (hue + 180) % 360
    const accentColor = `hsl(${accentHue}, 80%, 60%)`
    
    allTemplates.push({
      id: `gen-${counter}`,
      name: `${category} ${variation} ${counter}`,
      description: `Plantilla ${variation.toLowerCase()} para ${category.toLowerCase()}`,
      colors: [darkColor, baseColor, lightColor, accentColor]
    })
    
    counter++
  }
  
  return allTemplates
}

export const ALL_TEMPLATES = generateTemplates()
