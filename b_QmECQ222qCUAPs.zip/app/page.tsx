'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { SplashScreen } from '@/components/splash-screen'
import { LockScreen } from '@/components/lock-screen'
import { EmailForm } from '@/components/email-form'
import { EmailList } from '@/components/email-list'
import { SettingsPanel } from '@/components/settings-panel'
import { AppPublisher } from '@/components/app-publisher'
import { EmailAccount, useEmailStore } from '@/lib/store'
import { Mail, Plus, Settings, Shield, Dumbbell, Lock, Zap, Rocket } from 'lucide-react'

export default function HomePage() {
  const [showSplash, setShowSplash] = useState(true)
  const [formOpen, setFormOpen] = useState(false)
  const [settingsOpen, setSettingsOpen] = useState(false)
  const [publisherOpen, setPublisherOpen] = useState(false)
  const [editAccount, setEditAccount] = useState<EmailAccount | null>(null)
  const [mounted, setMounted] = useState(false)

  const { settings, accounts, publishedApps } = useEmailStore()

  useEffect(() => {
    setMounted(true)
    if (!settings.showSplash) {
      setShowSplash(false)
    }
  }, [settings.showSplash])

  const handleEditAccount = (account: EmailAccount) => {
    setEditAccount(account)
    setFormOpen(true)
  }

  const handleFormClose = (open: boolean) => {
    setFormOpen(open)
    if (!open) {
      setEditAccount(null)
    }
  }

  if (!mounted) {
    return null
  }

  // Show splash screen
  if (showSplash && settings.showSplash) {
    return <SplashScreen onComplete={() => setShowSplash(false)} />
  }

  // Show lock screen if app is locked
  if (settings.appPassword && settings.isLocked) {
    return <LockScreen />
  }

  return (
    <div className="min-h-screen bg-background gym-pattern">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-background/90 backdrop-blur-lg border-b border-primary/20">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary to-accent flex items-center justify-center animate-pulse-glow">
                <Shield className="h-7 w-7 text-primary-foreground" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-foreground neon-text">{settings.appName}</h1>
                <p className="text-xs text-muted-foreground flex items-center gap-1">
                  <Dumbbell className="h-3 w-3" />
                  Tu boveda segura de correos
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              {settings.appPassword && (
                <Button 
                  variant="ghost" 
                  size="icon"
                  onClick={() => useEmailStore.getState().lockApp()}
                  className="text-primary hover:text-primary hover:bg-primary/10"
                >
                  <Lock className="h-5 w-5" />
                </Button>
              )}
              <Button 
                variant="ghost" 
                size="icon"
                onClick={() => setPublisherOpen(true)}
                className="hover:bg-accent/10 text-accent"
                title="Publicar Apps"
              >
                <Rocket className="h-5 w-5" />
              </Button>
              <Button 
                variant="ghost" 
                size="icon" 
                onClick={() => setSettingsOpen(true)}
                className="hover:bg-primary/10"
              >
                <Settings className="h-5 w-5" />
              </Button>
              <Button onClick={() => setFormOpen(true)} className="hidden sm:flex gym-button">
                <Plus className="h-4 w-4 mr-2" />
                Agregar Correo
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-6 pb-24 sm:pb-6">
        {/* Stats Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 mb-6">
          <div className="gym-card p-4 rounded-xl border border-primary/20 animate-border-pulse">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary/30 to-primary/10 flex items-center justify-center">
                <Mail className="h-6 w-6 text-primary" />
              </div>
              <div>
                <p className="text-3xl font-bold text-primary stat-number">{accounts.length}</p>
                <p className="text-xs text-muted-foreground">Total</p>
              </div>
            </div>
          </div>
          
          <div className="gym-card p-4 rounded-xl border border-red-500/20">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-red-500/30 to-red-500/10 flex items-center justify-center">
                <span className="text-xl font-bold text-red-400">G</span>
              </div>
              <div>
                <p className="text-3xl font-bold text-red-400 stat-number">
                  {accounts.filter((a) => a.provider === 'Gmail').length}
                </p>
                <p className="text-xs text-muted-foreground">Gmail</p>
              </div>
            </div>
          </div>
          
          <div className="gym-card p-4 rounded-xl border border-blue-500/20">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-500/30 to-blue-500/10 flex items-center justify-center">
                <span className="text-xl font-bold text-blue-400">H</span>
              </div>
              <div>
                <p className="text-3xl font-bold text-blue-400 stat-number">
                  {accounts.filter((a) => a.provider === 'Hotmail' || a.provider === 'Outlook').length}
                </p>
                <p className="text-xs text-muted-foreground">Hotmail</p>
              </div>
            </div>
          </div>
          
          <div className="gym-card p-4 rounded-xl border border-accent/20">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-accent/30 to-accent/10 flex items-center justify-center">
                <Zap className="h-6 w-6 text-accent" />
              </div>
              <div>
                <p className="text-3xl font-bold text-accent stat-number">
                  {accounts.filter((a) => !['Gmail', 'Hotmail', 'Outlook'].includes(a.provider)).length}
                </p>
                <p className="text-xs text-muted-foreground">Otros</p>
              </div>
            </div>
          </div>

          <div 
            className="gym-card p-4 rounded-xl border border-orange-500/20 cursor-pointer hover:border-orange-500/50 transition-colors col-span-2 sm:col-span-1"
            onClick={() => setPublisherOpen(true)}
          >
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-orange-500/30 to-orange-500/10 flex items-center justify-center">
                <Rocket className="h-6 w-6 text-orange-400" />
              </div>
              <div>
                <p className="text-3xl font-bold text-orange-400 stat-number">{publishedApps.length}</p>
                <p className="text-xs text-muted-foreground">Apps</p>
              </div>
            </div>
          </div>
        </div>

        {/* Email List */}
        <EmailList onEditAccount={handleEditAccount} />
      </main>

      {/* Mobile FAB */}
      <div className="fixed bottom-6 right-6 sm:hidden flex flex-col gap-3">
        <Button
          size="lg"
          className="h-14 w-14 rounded-full shadow-lg bg-orange-500 hover:bg-orange-600"
          onClick={() => setPublisherOpen(true)}
        >
          <Rocket className="h-6 w-6" />
        </Button>
        <Button
          size="lg"
          className="h-16 w-16 rounded-full shadow-lg gym-button"
          onClick={() => setFormOpen(true)}
        >
          <Plus className="h-7 w-7" />
        </Button>
      </div>

      {/* Decorative Elements */}
      <div className="fixed bottom-4 left-4 opacity-10 pointer-events-none hidden lg:block">
        <Dumbbell className="h-24 w-24 text-primary animate-float" />
      </div>

      {/* Modals */}
      <EmailForm open={formOpen} onOpenChange={handleFormClose} editAccount={editAccount} />
      <SettingsPanel open={settingsOpen} onOpenChange={setSettingsOpen} />
      <AppPublisher open={publisherOpen} onOpenChange={setPublisherOpen} />
    </div>
  )
}
