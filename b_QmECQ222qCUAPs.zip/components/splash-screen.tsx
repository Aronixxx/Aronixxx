'use client'

import { useEffect, useState, useCallback } from 'react'
import { Dumbbell, Shield, Mail, Lock, Zap, Activity } from 'lucide-react'

interface MatrixChar {
  id: number
  char: string
  x: number
  delay: number
  duration: number
}

export function SplashScreen({ onComplete }: { onComplete: () => void }) {
  const [matrixChars, setMatrixChars] = useState<MatrixChar[]>([])
  const [terminalLines, setTerminalLines] = useState<string[]>([])
  const [showLogo, setShowLogo] = useState(false)
  const [progress, setProgress] = useState(0)

  const generateMatrixChars = useCallback(() => {
    const chars: MatrixChar[] = []
    const characters = 'アイウエオカキクケコサシスセソ0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ@#$%&*<>{}[]|/\\GYM'
    
    for (let i = 0; i < 80; i++) {
      chars.push({
        id: i,
        char: characters[Math.floor(Math.random() * characters.length)],
        x: Math.random() * 100,
        delay: Math.random() * 2,
        duration: 1.5 + Math.random() * 2.5,
      })
    }
    return chars
  }, [])

  useEffect(() => {
    setMatrixChars(generateMatrixChars())

    const lines = [
      '> Initializing GymMail Vault v2.0...',
      '> Loading security protocols... [OK]',
      '> Encrypting AES-256 connection...',
      '> Accessing email database...',
      '> Loading 1000+ templates...',
      '> Activating BEAST MODE...',
      '> System ready. LETS GO!',
    ]

    let lineIndex = 0
    const lineInterval = setInterval(() => {
      if (lineIndex < lines.length) {
        setTerminalLines((prev) => [...prev, lines[lineIndex]])
        setProgress(Math.min(100, ((lineIndex + 1) / lines.length) * 100))
        lineIndex++
      } else {
        clearInterval(lineInterval)
        setTimeout(() => setShowLogo(true), 300)
        setTimeout(onComplete, 2000)
      }
    }, 350)

    return () => clearInterval(lineInterval)
  }, [generateMatrixChars, onComplete])

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-background overflow-hidden gym-pattern">
      {/* Matrix Rain Background */}
      <div className="absolute inset-0 overflow-hidden">
        {matrixChars.map((char) => (
          <span
            key={char.id}
            className="absolute text-primary font-mono text-lg animate-matrix font-bold"
            style={{
              left: `${char.x}%`,
              animationDelay: `${char.delay}s`,
              animationDuration: `${char.duration}s`,
              textShadow: '0 0 10px currentColor',
            }}
          >
            {char.char}
          </span>
        ))}
      </div>

      {/* Floating Gym Icons */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-[8%] left-[8%] animate-float" style={{ animationDelay: '0s' }}>
          <Dumbbell className="w-16 h-16 text-primary/30" />
        </div>
        <div className="absolute top-[15%] right-[12%] animate-float" style={{ animationDelay: '0.5s' }}>
          <Shield className="w-14 h-14 text-accent/30" />
        </div>
        <div className="absolute top-[40%] left-[5%] animate-float" style={{ animationDelay: '1s' }}>
          <Mail className="w-12 h-12 text-primary/25" />
        </div>
        <div className="absolute bottom-[35%] right-[8%] animate-float" style={{ animationDelay: '1.5s' }}>
          <Lock className="w-10 h-10 text-primary/30" />
        </div>
        <div className="absolute bottom-[20%] left-[15%] animate-float" style={{ animationDelay: '0.8s' }}>
          <Zap className="w-14 h-14 text-accent/25" />
        </div>
        <div className="absolute bottom-[15%] right-[20%] animate-float" style={{ animationDelay: '1.2s' }}>
          <Activity className="w-12 h-12 text-orange-500/30" />
        </div>
        <div className="absolute top-[60%] right-[5%] animate-float" style={{ animationDelay: '0.3s' }}>
          <Dumbbell className="w-10 h-10 text-primary/20" />
        </div>
      </div>

      {/* Terminal Content */}
      <div className="relative z-10 w-full max-w-lg mx-4">
        <div className="gym-card border-2 border-primary/40 rounded-xl shadow-2xl overflow-hidden animate-pulse-glow">
          {/* Terminal Header */}
          <div className="flex items-center gap-2 px-4 py-3 bg-gradient-to-r from-secondary to-secondary/80 border-b border-primary/30">
            <div className="w-3 h-3 rounded-full bg-red-500"></div>
            <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
            <div className="w-3 h-3 rounded-full bg-primary"></div>
            <span className="ml-2 text-sm text-primary font-mono font-bold">root@gymmail-vault ~ $</span>
          </div>

          {/* Terminal Body */}
          <div className="p-5 font-mono text-sm min-h-[220px] bg-gradient-to-b from-card to-background">
            {terminalLines.filter(Boolean).map((line, index) => (
              <div 
                key={index} 
                className={`mb-2 animate-in fade-in slide-in-from-left duration-300 ${
                  line?.includes('[OK]') ? 'text-primary' : 
                  line?.includes('BEAST MODE') ? 'text-orange-500 font-bold' :
                  line?.includes('LETS GO') ? 'text-primary font-bold neon-text' :
                  'text-foreground'
                }`}
              >
                {line}
                {index === terminalLines.filter(Boolean).length - 1 && !showLogo && (
                  <span className="inline-block w-3 h-5 ml-1 bg-primary animate-pulse"></span>
                )}
              </div>
            ))}
          </div>

          {/* Progress Bar */}
          <div className="px-5 pb-4">
            <div className="h-2 bg-secondary rounded-full overflow-hidden">
              <div 
                className="h-full bg-gradient-to-r from-primary to-accent transition-all duration-500 ease-out"
                style={{ width: `${progress}%` }}
              />
            </div>
            <p className="text-xs text-muted-foreground mt-2 text-center font-mono">
              Loading... {Math.round(progress)}%
            </p>
          </div>
        </div>

        {/* Logo */}
        {showLogo && (
          <div className="mt-8 text-center animate-in fade-in zoom-in duration-500">
            <div className="inline-flex items-center gap-4">
              <div className="w-16 h-16 rounded-xl bg-gradient-to-br from-primary to-accent flex items-center justify-center animate-pulse-glow">
                <Shield className="w-10 h-10 text-primary-foreground" />
              </div>
              <div className="text-left">
                <h1 className="text-4xl font-black text-foreground neon-text">
                  GymMail <span className="text-primary">Vault</span>
                </h1>
                <p className="text-muted-foreground flex items-center gap-2">
                  <Dumbbell className="h-4 w-4 text-primary" />
                  Tu boveda segura de correos
                  <Zap className="h-4 w-4 text-accent" />
                </p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
