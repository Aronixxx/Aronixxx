'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { ScrollArea } from '@/components/ui/scroll-area'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog'
import { APP_CATEGORIES, PublishedApp, useEmailStore } from '@/lib/store'
import { 
  Plus, 
  X, 
  Upload, 
  Link, 
  Download, 
  Globe, 
  Smartphone, 
  Image as ImageIcon,
  Trash2,
  Edit,
  Eye,
  Dumbbell,
  Rocket,
  Share2,
  Copy,
  Check
} from 'lucide-react'

interface AppPublisherProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

export function AppPublisher({ open, onOpenChange }: AppPublisherProps) {
  const { publishedApps, addPublishedApp, updatePublishedApp, deletePublishedApp } = useEmailStore()
  const [showForm, setShowForm] = useState(false)
  const [editingApp, setEditingApp] = useState<PublishedApp | null>(null)
  const [viewingApp, setViewingApp] = useState<PublishedApp | null>(null)
  const [copied, setCopied] = useState<string | null>(null)
  
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    details: '',
    version: '1.0.0',
    downloadLink: '',
    apkLink: '',
    websiteLink: '',
    screenshots: [] as string[],
    loginImage: '',
    icon: '',
    category: 'Fitness',
  })

  const resetForm = () => {
    setFormData({
      name: '',
      description: '',
      details: '',
      version: '1.0.0',
      downloadLink: '',
      apkLink: '',
      websiteLink: '',
      screenshots: [],
      loginImage: '',
      icon: '',
      category: 'Fitness',
    })
    setEditingApp(null)
  }

  const handleImageUpload = (field: 'icon' | 'loginImage' | 'screenshots', files: FileList | null) => {
    if (!files) return
    
    Array.from(files).forEach(file => {
      const reader = new FileReader()
      reader.onload = (e) => {
        const result = e.target?.result as string
        if (field === 'screenshots') {
          setFormData(prev => ({
            ...prev,
            screenshots: [...prev.screenshots, result]
          }))
        } else {
          setFormData(prev => ({
            ...prev,
            [field]: result
          }))
        }
      }
      reader.readAsDataURL(file)
    })
  }

  const removeScreenshot = (index: number) => {
    setFormData(prev => ({
      ...prev,
      screenshots: prev.screenshots.filter((_, i) => i !== index)
    }))
  }

  const handleSubmit = () => {
    if (!formData.name) return

    if (editingApp) {
      updatePublishedApp(editingApp.id, formData)
    } else {
      addPublishedApp(formData)
    }
    
    resetForm()
    setShowForm(false)
  }

  const handleEdit = (app: PublishedApp) => {
    setFormData({
      name: app.name,
      description: app.description,
      details: app.details,
      version: app.version,
      downloadLink: app.downloadLink,
      apkLink: app.apkLink,
      websiteLink: app.websiteLink,
      screenshots: app.screenshots,
      loginImage: app.loginImage,
      icon: app.icon,
      category: app.category,
    })
    setEditingApp(app)
    setShowForm(true)
  }

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text)
    setCopied(id)
    setTimeout(() => setCopied(null), 2000)
  }

  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden gym-card border-primary/30">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 neon-text text-xl">
              <Rocket className="h-6 w-6 text-primary" />
              Publicar Aplicaciones
            </DialogTitle>
            <DialogDescription>
              Administra y publica tus aplicaciones con enlaces, APK y capturas de pantalla
            </DialogDescription>
          </DialogHeader>

          <div className="flex justify-end mb-4">
            <Button 
              onClick={() => { resetForm(); setShowForm(true) }} 
              className="gym-button"
            >
              <Plus className="h-4 w-4 mr-2" />
              Nueva App
            </Button>
          </div>

          <ScrollArea className="h-[60vh] pr-4">
            {publishedApps.length === 0 ? (
              <div className="text-center py-16">
                <div className="inline-flex items-center justify-center w-20 h-20 rounded-2xl bg-gradient-to-br from-primary/20 to-accent/20 mb-4">
                  <Smartphone className="h-10 w-10 text-primary" />
                </div>
                <h3 className="text-lg font-bold text-foreground mb-2">Sin aplicaciones publicadas</h3>
                <p className="text-muted-foreground text-sm">
                  Agrega tu primera aplicacion para compartirla
                </p>
              </div>
            ) : (
              <div className="grid gap-4 md:grid-cols-2">
                {publishedApps.map((app) => (
                  <Card key={app.id} className="gym-card border-primary/20 hover:border-primary/40 transition-all">
                    <CardHeader className="pb-2">
                      <div className="flex items-start gap-3">
                        {app.icon ? (
                          <img 
                            src={app.icon} 
                            alt={app.name} 
                            className="w-14 h-14 rounded-xl object-cover border border-primary/30"
                          />
                        ) : (
                          <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-primary/30 to-accent/30 flex items-center justify-center">
                            <Dumbbell className="h-7 w-7 text-primary" />
                          </div>
                        )}
                        <div className="flex-1 min-w-0">
                          <CardTitle className="text-base truncate">{app.name}</CardTitle>
                          <CardDescription className="text-xs">v{app.version}</CardDescription>
                          <Badge variant="outline" className="mt-1 text-xs gym-badge">
                            {app.category}
                          </Badge>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="pt-2">
                      <p className="text-sm text-muted-foreground line-clamp-2 mb-3">
                        {app.description}
                      </p>
                      
                      {app.screenshots.length > 0 && (
                        <div className="flex gap-1 mb-3 overflow-x-auto">
                          {app.screenshots.slice(0, 3).map((ss, i) => (
                            <img 
                              key={i} 
                              src={ss} 
                              alt={`Screenshot ${i+1}`}
                              className="w-12 h-20 object-cover rounded border border-primary/20"
                            />
                          ))}
                          {app.screenshots.length > 3 && (
                            <div className="w-12 h-20 rounded bg-secondary/50 flex items-center justify-center text-xs text-muted-foreground">
                              +{app.screenshots.length - 3}
                            </div>
                          )}
                        </div>
                      )}

                      <div className="flex flex-wrap gap-1 mb-3">
                        {app.downloadLink && (
                          <Badge variant="secondary" className="text-xs">
                            <Link className="h-3 w-3 mr-1" />
                            Link
                          </Badge>
                        )}
                        {app.apkLink && (
                          <Badge variant="secondary" className="text-xs">
                            <Download className="h-3 w-3 mr-1" />
                            APK
                          </Badge>
                        )}
                        {app.websiteLink && (
                          <Badge variant="secondary" className="text-xs">
                            <Globe className="h-3 w-3 mr-1" />
                            Web
                          </Badge>
                        )}
                      </div>

                      <div className="flex gap-2">
                        <Button 
                          variant="outline" 
                          size="sm" 
                          className="flex-1 border-primary/30"
                          onClick={() => setViewingApp(app)}
                        >
                          <Eye className="h-3 w-3 mr-1" />
                          Ver
                        </Button>
                        <Button 
                          variant="outline" 
                          size="sm"
                          className="border-primary/30"
                          onClick={() => handleEdit(app)}
                        >
                          <Edit className="h-3 w-3" />
                        </Button>
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button variant="destructive" size="sm">
                              <Trash2 className="h-3 w-3" />
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent className="gym-card">
                            <AlertDialogHeader>
                              <AlertDialogTitle>Eliminar aplicacion</AlertDialogTitle>
                              <AlertDialogDescription>
                                Esta accion no se puede deshacer. Se eliminara permanentemente.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Cancelar</AlertDialogCancel>
                              <AlertDialogAction 
                                onClick={() => deletePublishedApp(app.id)}
                                className="bg-destructive text-destructive-foreground"
                              >
                                Eliminar
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </ScrollArea>
        </DialogContent>
      </Dialog>

      {/* Form Dialog */}
      <Dialog open={showForm} onOpenChange={(open) => { if (!open) resetForm(); setShowForm(open) }}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-hidden gym-card border-primary/30">
          <DialogHeader>
            <DialogTitle className="neon-text">
              {editingApp ? 'Editar Aplicacion' : 'Nueva Aplicacion'}
            </DialogTitle>
          </DialogHeader>

          <ScrollArea className="h-[70vh] pr-4">
            <div className="space-y-4 pb-4">
              {/* Icon & Basic Info */}
              <div className="flex gap-4">
                <div className="space-y-2">
                  <Label>Icono</Label>
                  <div 
                    className="w-20 h-20 rounded-xl border-2 border-dashed border-primary/30 flex items-center justify-center cursor-pointer hover:border-primary/60 transition-colors overflow-hidden"
                    onClick={() => document.getElementById('icon-upload')?.click()}
                  >
                    {formData.icon ? (
                      <img src={formData.icon} alt="Icon" className="w-full h-full object-cover" />
                    ) : (
                      <Upload className="h-8 w-8 text-primary/50" />
                    )}
                  </div>
                  <input 
                    id="icon-upload" 
                    type="file" 
                    accept="image/*" 
                    className="hidden"
                    onChange={(e) => handleImageUpload('icon', e.target.files)}
                  />
                </div>
                
                <div className="flex-1 space-y-3">
                  <div className="space-y-2">
                    <Label htmlFor="app-name">Nombre de la App *</Label>
                    <Input
                      id="app-name"
                      value={formData.name}
                      onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                      placeholder="Mi App Fitness"
                      className="bg-input border-primary/20"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-2">
                      <Label htmlFor="version">Version</Label>
                      <Input
                        id="version"
                        value={formData.version}
                        onChange={(e) => setFormData(prev => ({ ...prev, version: e.target.value }))}
                        placeholder="1.0.0"
                        className="bg-input border-primary/20"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Categoria</Label>
                      <Select
                        value={formData.category}
                        onValueChange={(value) => setFormData(prev => ({ ...prev, category: value }))}
                      >
                        <SelectTrigger className="bg-input border-primary/20">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {APP_CATEGORIES.map((cat) => (
                            <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </div>
              </div>

              {/* Description */}
              <div className="space-y-2">
                <Label htmlFor="description">Descripcion corta</Label>
                <Input
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                  placeholder="Una breve descripcion de tu app"
                  className="bg-input border-primary/20"
                />
              </div>

              {/* Details */}
              <div className="space-y-2">
                <Label htmlFor="details">Detalles completos</Label>
                <Textarea
                  id="details"
                  value={formData.details}
                  onChange={(e) => setFormData(prev => ({ ...prev, details: e.target.value }))}
                  placeholder="Describe todas las caracteristicas, requisitos, instrucciones de uso..."
                  className="bg-input border-primary/20 min-h-[100px]"
                />
              </div>

              {/* Links */}
              <div className="space-y-3">
                <Label className="text-primary">Enlaces de descarga</Label>
                
                <div className="space-y-2">
                  <Label htmlFor="downloadLink" className="text-xs text-muted-foreground flex items-center gap-1">
                    <Link className="h-3 w-3" /> Link directo
                  </Label>
                  <Input
                    id="downloadLink"
                    value={formData.downloadLink}
                    onChange={(e) => setFormData(prev => ({ ...prev, downloadLink: e.target.value }))}
                    placeholder="https://..."
                    className="bg-input border-primary/20"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="apkLink" className="text-xs text-muted-foreground flex items-center gap-1">
                    <Download className="h-3 w-3" /> APK (Android)
                  </Label>
                  <Input
                    id="apkLink"
                    value={formData.apkLink}
                    onChange={(e) => setFormData(prev => ({ ...prev, apkLink: e.target.value }))}
                    placeholder="https://...app.apk"
                    className="bg-input border-primary/20"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="websiteLink" className="text-xs text-muted-foreground flex items-center gap-1">
                    <Globe className="h-3 w-3" /> Sitio Web
                  </Label>
                  <Input
                    id="websiteLink"
                    value={formData.websiteLink}
                    onChange={(e) => setFormData(prev => ({ ...prev, websiteLink: e.target.value }))}
                    placeholder="https://miapp.com"
                    className="bg-input border-primary/20"
                  />
                </div>
              </div>

              {/* Login Image */}
              <div className="space-y-2">
                <Label className="flex items-center gap-2">
                  <ImageIcon className="h-4 w-4 text-primary" />
                  Imagen de Login / Pantalla de inicio
                </Label>
                <div 
                  className="h-40 rounded-xl border-2 border-dashed border-primary/30 flex items-center justify-center cursor-pointer hover:border-primary/60 transition-colors overflow-hidden"
                  onClick={() => document.getElementById('login-upload')?.click()}
                >
                  {formData.loginImage ? (
                    <div className="relative w-full h-full">
                      <img src={formData.loginImage} alt="Login" className="w-full h-full object-cover" />
                      <Button 
                        variant="destructive" 
                        size="icon" 
                        className="absolute top-2 right-2 h-6 w-6"
                        onClick={(e) => { e.stopPropagation(); setFormData(prev => ({ ...prev, loginImage: '' })) }}
                      >
                        <X className="h-3 w-3" />
                      </Button>
                    </div>
                  ) : (
                    <div className="text-center">
                      <Upload className="h-10 w-10 text-primary/50 mx-auto mb-2" />
                      <p className="text-sm text-muted-foreground">Subir imagen de login</p>
                    </div>
                  )}
                </div>
                <input 
                  id="login-upload" 
                  type="file" 
                  accept="image/*" 
                  className="hidden"
                  onChange={(e) => handleImageUpload('loginImage', e.target.files)}
                />
              </div>

              {/* Screenshots */}
              <div className="space-y-2">
                <Label className="flex items-center gap-2">
                  <ImageIcon className="h-4 w-4 text-primary" />
                  Capturas de pantalla
                </Label>
                <div className="flex flex-wrap gap-2">
                  {formData.screenshots.map((ss, index) => (
                    <div key={index} className="relative w-20 h-36 rounded-lg overflow-hidden border border-primary/30">
                      <img src={ss} alt={`Screenshot ${index+1}`} className="w-full h-full object-cover" />
                      <Button 
                        variant="destructive" 
                        size="icon" 
                        className="absolute top-1 right-1 h-5 w-5"
                        onClick={() => removeScreenshot(index)}
                      >
                        <X className="h-3 w-3" />
                      </Button>
                    </div>
                  ))}
                  <div 
                    className="w-20 h-36 rounded-lg border-2 border-dashed border-primary/30 flex items-center justify-center cursor-pointer hover:border-primary/60 transition-colors"
                    onClick={() => document.getElementById('screenshots-upload')?.click()}
                  >
                    <Plus className="h-6 w-6 text-primary/50" />
                  </div>
                </div>
                <input 
                  id="screenshots-upload" 
                  type="file" 
                  accept="image/*" 
                  multiple
                  className="hidden"
                  onChange={(e) => handleImageUpload('screenshots', e.target.files)}
                />
                <p className="text-xs text-muted-foreground">Puedes agregar multiples capturas</p>
              </div>

              <Button onClick={handleSubmit} className="w-full gym-button" disabled={!formData.name}>
                <Rocket className="h-4 w-4 mr-2" />
                {editingApp ? 'Guardar cambios' : 'Publicar App'}
              </Button>
            </div>
          </ScrollArea>
        </DialogContent>
      </Dialog>

      {/* View Dialog */}
      <Dialog open={!!viewingApp} onOpenChange={(open) => !open && setViewingApp(null)}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-hidden gym-card border-primary/30">
          {viewingApp && (
            <>
              <DialogHeader>
                <div className="flex items-start gap-4">
                  {viewingApp.icon ? (
                    <img 
                      src={viewingApp.icon} 
                      alt={viewingApp.name} 
                      className="w-20 h-20 rounded-2xl object-cover border-2 border-primary/30"
                    />
                  ) : (
                    <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-primary/30 to-accent/30 flex items-center justify-center">
                      <Dumbbell className="h-10 w-10 text-primary" />
                    </div>
                  )}
                  <div>
                    <DialogTitle className="text-2xl neon-text">{viewingApp.name}</DialogTitle>
                    <DialogDescription className="flex items-center gap-2 mt-1">
                      <Badge className="gym-badge">v{viewingApp.version}</Badge>
                      <Badge variant="outline">{viewingApp.category}</Badge>
                    </DialogDescription>
                  </div>
                </div>
              </DialogHeader>

              <ScrollArea className="h-[60vh] pr-4">
                <div className="space-y-6">
                  {/* Login Image */}
                  {viewingApp.loginImage && (
                    <div className="space-y-2">
                      <Label className="text-primary">Pantalla de Login</Label>
                      <img 
                        src={viewingApp.loginImage} 
                        alt="Login" 
                        className="w-full max-h-64 object-contain rounded-xl border border-primary/30"
                      />
                    </div>
                  )}

                  {/* Screenshots */}
                  {viewingApp.screenshots.length > 0 && (
                    <div className="space-y-2">
                      <Label className="text-primary">Capturas de pantalla</Label>
                      <div className="flex gap-3 overflow-x-auto pb-2">
                        {viewingApp.screenshots.map((ss, i) => (
                          <img 
                            key={i} 
                            src={ss} 
                            alt={`Screenshot ${i+1}`}
                            className="h-48 w-auto rounded-xl border border-primary/30"
                          />
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Description */}
                  <div className="space-y-2">
                    <Label className="text-primary">Descripcion</Label>
                    <p className="text-foreground">{viewingApp.description}</p>
                  </div>

                  {/* Details */}
                  {viewingApp.details && (
                    <div className="space-y-2">
                      <Label className="text-primary">Detalles</Label>
                      <p className="text-muted-foreground whitespace-pre-wrap">{viewingApp.details}</p>
                    </div>
                  )}

                  {/* Links */}
                  <div className="space-y-3">
                    <Label className="text-primary">Enlaces de descarga</Label>
                    
                    {viewingApp.downloadLink && (
                      <div className="flex items-center gap-2 p-3 rounded-lg bg-secondary/50 border border-primary/20">
                        <Link className="h-5 w-5 text-primary" />
                        <span className="flex-1 truncate text-sm">{viewingApp.downloadLink}</span>
                        <Button 
                          variant="ghost" 
                          size="sm"
                          onClick={() => copyToClipboard(viewingApp.downloadLink, 'download')}
                        >
                          {copied === 'download' ? <Check className="h-4 w-4 text-primary" /> : <Copy className="h-4 w-4" />}
                        </Button>
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => window.open(viewingApp.downloadLink, '_blank')}
                        >
                          <Share2 className="h-4 w-4" />
                        </Button>
                      </div>
                    )}

                    {viewingApp.apkLink && (
                      <div className="flex items-center gap-2 p-3 rounded-lg bg-secondary/50 border border-primary/20">
                        <Download className="h-5 w-5 text-orange-500" />
                        <span className="flex-1 truncate text-sm">{viewingApp.apkLink}</span>
                        <Button 
                          variant="ghost" 
                          size="sm"
                          onClick={() => copyToClipboard(viewingApp.apkLink, 'apk')}
                        >
                          {copied === 'apk' ? <Check className="h-4 w-4 text-primary" /> : <Copy className="h-4 w-4" />}
                        </Button>
                        <Button 
                          variant="outline" 
                          size="sm"
                          className="bg-orange-500/10 border-orange-500/30 hover:bg-orange-500/20"
                          onClick={() => window.open(viewingApp.apkLink, '_blank')}
                        >
                          <Download className="h-4 w-4 text-orange-500" />
                        </Button>
                      </div>
                    )}

                    {viewingApp.websiteLink && (
                      <div className="flex items-center gap-2 p-3 rounded-lg bg-secondary/50 border border-primary/20">
                        <Globe className="h-5 w-5 text-blue-500" />
                        <span className="flex-1 truncate text-sm">{viewingApp.websiteLink}</span>
                        <Button 
                          variant="ghost" 
                          size="sm"
                          onClick={() => copyToClipboard(viewingApp.websiteLink, 'web')}
                        >
                          {copied === 'web' ? <Check className="h-4 w-4 text-primary" /> : <Copy className="h-4 w-4" />}
                        </Button>
                        <Button 
                          variant="outline" 
                          size="sm"
                          className="bg-blue-500/10 border-blue-500/30 hover:bg-blue-500/20"
                          onClick={() => window.open(viewingApp.websiteLink, '_blank')}
                        >
                          <Globe className="h-4 w-4 text-blue-500" />
                        </Button>
                      </div>
                    )}
                  </div>

                  {/* Meta */}
                  <div className="text-xs text-muted-foreground pt-4 border-t border-primary/10">
                    <p>Creado: {new Date(viewingApp.createdAt).toLocaleDateString()}</p>
                    <p>Actualizado: {new Date(viewingApp.updatedAt).toLocaleDateString()}</p>
                  </div>
                </div>
              </ScrollArea>
            </>
          )}
        </DialogContent>
      </Dialog>
    </>
  )
}
