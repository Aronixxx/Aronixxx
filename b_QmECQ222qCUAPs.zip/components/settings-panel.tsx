'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { Badge } from '@/components/ui/badge'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
} from '@/components/ui/sheet'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Separator } from '@/components/ui/separator'
import { EMAIL_PROVIDERS, EXPORT_TEMPLATES, ALL_TEMPLATES, useEmailStore } from '@/lib/store'
import { 
  Download, 
  Trash2, 
  Upload, 
  Database, 
  Shield, 
  Palette, 
  Lock, 
  Unlock, 
  Eye, 
  EyeOff,
  FileText,
  Image,
  FileSpreadsheet,
  Search,
  Dumbbell,
  Zap,
  Sparkles
} from 'lucide-react'
import jsPDF from 'jspdf'

interface SettingsPanelProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

interface Template {
  id: string
  name: string
  description: string
  colors: string[]
}

export function SettingsPanel({ open, onOpenChange }: SettingsPanelProps) {
  const { settings, updateSettings, setAppPassword, lockApp, accounts, deleteAll, importAccounts, exportAccounts } = useEmailStore()
  const [importError, setImportError] = useState('')
  const [newPassword, setNewPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  const [currentPassword, setCurrentPassword] = useState('')
  const [showPasswords, setShowPasswords] = useState(false)
  const [passwordError, setPasswordError] = useState('')
  const [templateSearch, setTemplateSearch] = useState('')
  const [selectedCategory, setSelectedCategory] = useState<string>('all')
  const [templatesOpen, setTemplatesOpen] = useState(false)
  const [selectedTemplate, setSelectedTemplate] = useState<Template | null>(null)

  const handleExportJSON = () => {
    const data = exportAccounts()
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `gymmail-vault-backup-${new Date().toISOString().split('T')[0]}.json`
    a.click()
    URL.revokeObjectURL(url)
  }

  const handleExportPDF = (template?: Template) => {
    const doc = new jsPDF()
    const data = exportAccounts()
    
    const colors = template?.colors || ['#0a0a0a', '#00ff41', '#ffffff', '#39ff14']

    // Header with template colors
    doc.setFillColor(colors[0])
    doc.rect(0, 0, 210, 40, 'F')
    
    doc.setFontSize(24)
    doc.setTextColor(colors[1])
    doc.text(settings.appName, 20, 25)

    doc.setFontSize(10)
    doc.setTextColor(colors[2])
    doc.text(`Exportado: ${new Date().toLocaleString()}`, 20, 33)
    doc.text(`Total de cuentas: ${data.length}`, 120, 33)
    if (template) {
      doc.text(`Plantilla: ${template.name}`, 20, 38)
    }

    let yPos = 50
    const pageHeight = 280

    data.forEach((account, index) => {
      if (yPos > pageHeight) {
        doc.addPage()
        doc.setFillColor(colors[0])
        doc.rect(0, 0, 210, 15, 'F')
        doc.setFontSize(10)
        doc.setTextColor(colors[1])
        doc.text(settings.appName, 20, 10)
        yPos = 25
      }

      // Card background
      doc.setFillColor(colors[0])
      doc.roundedRect(15, yPos - 5, 180, 28, 3, 3, 'F')

      doc.setFontSize(12)
      doc.setTextColor(colors[1])
      doc.text(`${index + 1}. ${account.email}`, 20, yPos + 3)

      doc.setFontSize(9)
      doc.setTextColor(colors[2])
      doc.text(`Proveedor: ${account.provider}`, 25, yPos + 10)
      doc.text(`Contrasena: ${account.password}`, 100, yPos + 10)
      
      if (account.phone) {
        doc.text(`Tel: ${account.phone}`, 25, yPos + 17)
      }
      if (account.tags.length) {
        doc.text(`Tags: ${account.tags.join(', ')}`, 100, yPos + 17)
      }

      yPos += 35
    })

    // Footer
    doc.setFontSize(8)
    doc.setTextColor(150, 150, 150)
    doc.text('Generado con GymMail Vault', 20, 290)

    doc.save(`gymmail-vault-${template?.id || 'default'}-${new Date().toISOString().split('T')[0]}.pdf`)
  }

  const handleExportCSV = () => {
    const data = exportAccounts()
    const headers = ['Email', 'Contrasena', 'Proveedor', 'Telefono', 'Correo Recuperacion', 'Etiquetas', 'Notas']
    const rows = data.map((acc) => [
      acc.email,
      acc.password,
      acc.provider,
      acc.phone || '',
      acc.recoveryEmail || '',
      acc.tags.join('; '),
      acc.notes || '',
    ])

    const csv = [headers.join(','), ...rows.map((r) => r.map((c) => `"${c}"`).join(','))].join('\n')
    const blob = new Blob([csv], { type: 'text/csv' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `gymmail-vault-backup-${new Date().toISOString().split('T')[0]}.csv`
    a.click()
    URL.revokeObjectURL(url)
  }

  const handleImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    setImportError('')
    const reader = new FileReader()

    reader.onload = () => {
      try {
        const content = reader.result as string

        if (file.name.endsWith('.json')) {
          const data = JSON.parse(content)
          if (Array.isArray(data)) {
            importAccounts(data)
          } else {
            setImportError('Formato JSON invalido')
          }
        } else if (file.name.endsWith('.csv')) {
          const lines = content.split('\n').slice(1)
          const importedAccounts = lines
            .filter((line) => line.trim())
            .map((line) => {
              const cols = line.match(/(".*?"|[^",\s]+)(?=\s*,|\s*$)/g) || []
              const clean = cols.map((c) => c.replace(/^"|"$/g, ''))
              return {
                email: clean[0] || '',
                password: clean[1] || '',
                provider: clean[2] || 'Gmail',
                phone: clean[3] || '',
                recoveryEmail: clean[4] || '',
                tags: clean[5] ? clean[5].split(';').map((t) => t.trim()) : [],
                notes: clean[6] || '',
              }
            })
          importAccounts(importedAccounts)
        } else {
          setImportError('Formato no soportado. Use JSON o CSV.')
        }
      } catch {
        setImportError('Error al leer el archivo')
      }
    }

    reader.readAsText(file)
    e.target.value = ''
  }

  const handleSetPassword = () => {
    setPasswordError('')
    
    if (settings.appPassword) {
      if (currentPassword !== settings.appPassword) {
        setPasswordError('La contrasena actual es incorrecta')
        return
      }
    }
    
    if (newPassword !== confirmPassword) {
      setPasswordError('Las contrasenas no coinciden')
      return
    }
    
    if (newPassword && newPassword.length < 4) {
      setPasswordError('La contrasena debe tener al menos 4 caracteres')
      return
    }
    
    setAppPassword(newPassword || null)
    setNewPassword('')
    setConfirmPassword('')
    setCurrentPassword('')
    setPasswordError('')
  }

  const handleRemovePassword = () => {
    if (currentPassword !== settings.appPassword) {
      setPasswordError('La contrasena actual es incorrecta')
      return
    }
    setAppPassword(null)
    setCurrentPassword('')
    setPasswordError('')
  }

  const filteredTemplates = ALL_TEMPLATES.filter(t => {
    const matchesSearch = t.name.toLowerCase().includes(templateSearch.toLowerCase()) ||
                         t.description.toLowerCase().includes(templateSearch.toLowerCase())
    
    if (selectedCategory === 'all') return matchesSearch
    
    const categoryTemplates = EXPORT_TEMPLATES[selectedCategory as keyof typeof EXPORT_TEMPLATES] || []
    return matchesSearch && categoryTemplates.some(ct => ct.id === t.id)
  })

  const templateCategories = [
    { id: 'all', name: 'Todas', icon: Sparkles, count: ALL_TEMPLATES.length },
    { id: 'gym', name: 'Gym', icon: Dumbbell, count: EXPORT_TEMPLATES.gym.length },
    { id: 'profesional', name: 'Profesional', icon: FileText, count: EXPORT_TEMPLATES.profesional.length },
    { id: 'tech', name: 'Tech', icon: Zap, count: EXPORT_TEMPLATES.tech.length },
    { id: 'gaming', name: 'Gaming', icon: Sparkles, count: EXPORT_TEMPLATES.gaming.length },
    { id: 'social', name: 'Social', icon: Image, count: EXPORT_TEMPLATES.social.length },
  ]

  return (
    <>
      <Sheet open={open} onOpenChange={onOpenChange}>
        <SheetContent className="w-full sm:max-w-lg overflow-y-auto gym-card border-l-primary/30">
          <SheetHeader>
            <SheetTitle className="flex items-center gap-2 neon-text">
              <Shield className="h-5 w-5 text-primary" />
              Administracion
            </SheetTitle>
            <SheetDescription>
              Configura y administra tu boveda de correos
            </SheetDescription>
          </SheetHeader>

          <Tabs defaultValue="general" className="mt-6">
            <TabsList className="grid grid-cols-3 w-full">
              <TabsTrigger value="general">General</TabsTrigger>
              <TabsTrigger value="security">Seguridad</TabsTrigger>
              <TabsTrigger value="data">Datos</TabsTrigger>
            </TabsList>

            {/* General Tab */}
            <TabsContent value="general" className="space-y-6 mt-4">
              <div className="space-y-4">
                <h3 className="text-sm font-medium flex items-center gap-2 text-primary">
                  <Palette className="h-4 w-4" />
                  Configuracion General
                </h3>

                <div className="space-y-3">
                  <div className="space-y-2">
                    <Label htmlFor="appName">Nombre de la App</Label>
                    <Input
                      id="appName"
                      value={settings.appName}
                      onChange={(e) => updateSettings({ appName: e.target.value })}
                      className="bg-input border-border focus:border-primary"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Proveedor por defecto</Label>
                    <Select
                      value={settings.defaultProvider}
                      onValueChange={(value) => updateSettings({ defaultProvider: value })}
                    >
                      <SelectTrigger className="bg-input border-border">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {EMAIL_PROVIDERS.map((provider) => (
                          <SelectItem key={provider} value={provider}>
                            {provider}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="flex items-center justify-between p-3 rounded-lg bg-secondary/50 border border-border">
                    <div className="space-y-0.5">
                      <Label>Pantalla de inicio</Label>
                      <p className="text-xs text-muted-foreground">Terminal estilo hacker</p>
                    </div>
                    <Switch
                      checked={settings.showSplash}
                      onCheckedChange={(checked) => updateSettings({ showSplash: checked })}
                    />
                  </div>
                </div>
              </div>

              {/* Stats */}
              <div className="space-y-4">
                <h3 className="text-sm font-medium text-primary">Estadisticas</h3>
                <div className="grid grid-cols-2 gap-3">
                  <div className="p-4 rounded-lg bg-gradient-to-br from-primary/20 to-primary/5 border border-primary/30">
                    <p className="text-3xl font-bold text-primary stat-number">{accounts.length}</p>
                    <p className="text-xs text-muted-foreground">Correos guardados</p>
                  </div>
                  <div className="p-4 rounded-lg bg-gradient-to-br from-accent/20 to-accent/5 border border-accent/30">
                    <p className="text-3xl font-bold text-accent stat-number">
                      {[...new Set(accounts.map((a) => a.provider))].length}
                    </p>
                    <p className="text-xs text-muted-foreground">Proveedores</p>
                  </div>
                </div>
              </div>
            </TabsContent>

            {/* Security Tab */}
            <TabsContent value="security" className="space-y-6 mt-4">
              <div className="space-y-4">
                <h3 className="text-sm font-medium flex items-center gap-2 text-primary">
                  <Lock className="h-4 w-4" />
                  Proteccion con Contrasena
                </h3>

                <div className="p-4 rounded-lg bg-secondary/50 border border-border space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      {settings.appPassword ? (
                        <Lock className="h-5 w-5 text-primary" />
                      ) : (
                        <Unlock className="h-5 w-5 text-muted-foreground" />
                      )}
                      <span className="font-medium">
                        {settings.appPassword ? 'Protegida' : 'Sin proteccion'}
                      </span>
                    </div>
                    <Badge variant={settings.appPassword ? 'default' : 'secondary'} className={settings.appPassword ? 'gym-badge' : ''}>
                      {settings.appPassword ? 'Activa' : 'Inactiva'}
                    </Badge>
                  </div>

                  {settings.appPassword && (
                    <div className="space-y-2">
                      <Label>Contrasena actual</Label>
                      <div className="relative">
                        <Input
                          type={showPasswords ? 'text' : 'password'}
                          placeholder="Ingresa tu contrasena actual"
                          value={currentPassword}
                          onChange={(e) => setCurrentPassword(e.target.value)}
                          className="pr-10 bg-input"
                        />
                        <Button
                          type="button"
                          variant="ghost"
                          size="icon"
                          className="absolute right-1 top-1/2 -translate-y-1/2 h-8 w-8"
                          onClick={() => setShowPasswords(!showPasswords)}
                        >
                          {showPasswords ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                        </Button>
                      </div>
                    </div>
                  )}

                  <div className="space-y-2">
                    <Label>{settings.appPassword ? 'Nueva contrasena' : 'Crear contrasena'}</Label>
                    <Input
                      type={showPasswords ? 'text' : 'password'}
                      placeholder="Minimo 4 caracteres"
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                      className="bg-input"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Confirmar contrasena</Label>
                    <Input
                      type={showPasswords ? 'text' : 'password'}
                      placeholder="Repite la contrasena"
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      className="bg-input"
                    />
                  </div>

                  {passwordError && (
                    <p className="text-sm text-destructive">{passwordError}</p>
                  )}

                  <div className="flex gap-2">
                    <Button 
                      onClick={handleSetPassword} 
                      className="flex-1 gym-button"
                      disabled={!newPassword || !confirmPassword}
                    >
                      <Lock className="h-4 w-4 mr-2" />
                      {settings.appPassword ? 'Cambiar' : 'Activar'}
                    </Button>
                    
                    {settings.appPassword && (
                      <Button 
                        variant="outline" 
                        onClick={handleRemovePassword}
                        disabled={!currentPassword}
                      >
                        <Unlock className="h-4 w-4 mr-2" />
                        Quitar
                      </Button>
                    )}
                  </div>
                </div>

                {settings.appPassword && (
                  <Button 
                    variant="outline" 
                    className="w-full border-primary/50 hover:bg-primary/10"
                    onClick={() => {
                      lockApp()
                      onOpenChange(false)
                    }}
                  >
                    <Lock className="h-4 w-4 mr-2" />
                    Bloquear App Ahora
                  </Button>
                )}
              </div>
            </TabsContent>

            {/* Data Tab */}
            <TabsContent value="data" className="space-y-6 mt-4">
              {/* Export/Import */}
              <div className="space-y-4">
                <h3 className="text-sm font-medium flex items-center gap-2 text-primary">
                  <Database className="h-4 w-4" />
                  Exportar Datos
                </h3>

                <div className="grid grid-cols-3 gap-2">
                  <Button variant="outline" size="sm" onClick={handleExportJSON} className="border-primary/30 hover:bg-primary/10">
                    <FileText className="h-4 w-4 mr-1" />
                    JSON
                  </Button>
                  <Button variant="outline" size="sm" onClick={() => handleExportPDF()} className="border-primary/30 hover:bg-primary/10">
                    <Image className="h-4 w-4 mr-1" />
                    PDF
                  </Button>
                  <Button variant="outline" size="sm" onClick={handleExportCSV} className="border-primary/30 hover:bg-primary/10">
                    <FileSpreadsheet className="h-4 w-4 mr-1" />
                    CSV
                  </Button>
                </div>

                {/* Templates Button */}
                <Button 
                  onClick={() => setTemplatesOpen(true)}
                  className="w-full gym-button"
                >
                  <Sparkles className="h-4 w-4 mr-2" />
                  Ver 1000 Plantillas de Exportacion
                </Button>
              </div>

              <Separator className="bg-border" />

              {/* Import */}
              <div className="space-y-4">
                <h3 className="text-sm font-medium flex items-center gap-2 text-primary">
                  <Upload className="h-4 w-4" />
                  Importar Datos
                </h3>

                <div className="space-y-2">
                  <Input
                    type="file"
                    accept=".json,.csv"
                    onChange={handleImport}
                    className="cursor-pointer bg-input border-border"
                  />
                  {importError && <p className="text-xs text-destructive">{importError}</p>}
                  <p className="text-xs text-muted-foreground">Soporta archivos JSON y CSV</p>
                </div>
              </div>

              <Separator className="bg-border" />

              {/* Danger Zone */}
              <div className="space-y-4">
                <h3 className="text-sm font-medium text-destructive">Zona de Peligro</h3>

                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button variant="destructive" className="w-full">
                      <Trash2 className="h-4 w-4 mr-2" />
                      Eliminar todos los correos
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Estas seguro?</AlertDialogTitle>
                      <AlertDialogDescription>
                        Esta accion eliminara permanentemente todos los {accounts.length} correos guardados. Esta accion no se puede deshacer.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Cancelar</AlertDialogCancel>
                      <AlertDialogAction onClick={deleteAll} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                        Eliminar todo
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </div>
            </TabsContent>
          </Tabs>
        </SheetContent>
      </Sheet>

      {/* Templates Dialog */}
      <Dialog open={templatesOpen} onOpenChange={setTemplatesOpen}>
        <DialogContent className="max-w-4xl h-[80vh] flex flex-col gym-card">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 neon-text">
              <Sparkles className="h-5 w-5 text-primary" />
              1000 Plantillas de Exportacion
            </DialogTitle>
            <DialogDescription>
              Selecciona una plantilla para exportar tus correos en PDF con estilo personalizado
            </DialogDescription>
          </DialogHeader>

          {/* Search and Filter */}
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Buscar plantillas..."
                value={templateSearch}
                onChange={(e) => setTemplateSearch(e.target.value)}
                className="pl-10 bg-input"
              />
            </div>
          </div>

          {/* Category Tabs */}
          <div className="flex gap-2 flex-wrap">
            {templateCategories.map((cat) => (
              <Button
                key={cat.id}
                variant={selectedCategory === cat.id ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSelectedCategory(cat.id)}
                className={selectedCategory === cat.id ? 'gym-button' : 'border-primary/30'}
              >
                <cat.icon className="h-3 w-3 mr-1" />
                {cat.name}
                <Badge variant="secondary" className="ml-1 text-xs">
                  {cat.count}
                </Badge>
              </Button>
            ))}
          </div>

          {/* Templates Grid */}
          <ScrollArea className="flex-1 pr-4">
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
              {filteredTemplates.slice(0, 100).map((template) => (
                <button
                  key={template.id}
                  onClick={() => setSelectedTemplate(template)}
                  className={`p-3 rounded-lg border transition-all text-left hover:border-primary/50 ${
                    selectedTemplate?.id === template.id 
                      ? 'border-primary bg-primary/10' 
                      : 'border-border bg-card'
                  }`}
                >
                  {/* Color Preview */}
                  <div className="flex gap-1 mb-2">
                    {template.colors.map((color, i) => (
                      <div
                        key={i}
                        className="w-4 h-4 rounded-full border border-border"
                        style={{ backgroundColor: color }}
                      />
                    ))}
                  </div>
                  <p className="text-sm font-medium truncate">{template.name}</p>
                  <p className="text-xs text-muted-foreground truncate">{template.description}</p>
                </button>
              ))}
            </div>
            {filteredTemplates.length > 100 && (
              <p className="text-center text-sm text-muted-foreground mt-4">
                Mostrando 100 de {filteredTemplates.length} plantillas. Usa el buscador para encontrar mas.
              </p>
            )}
          </ScrollArea>

          {/* Export Button */}
          <div className="flex gap-3 pt-4 border-t border-border">
            <Button variant="outline" onClick={() => setTemplatesOpen(false)} className="flex-1">
              Cancelar
            </Button>
            <Button 
              onClick={() => {
                if (selectedTemplate) {
                  handleExportPDF(selectedTemplate)
                  setTemplatesOpen(false)
                }
              }}
              disabled={!selectedTemplate}
              className="flex-1 gym-button"
            >
              <Download className="h-4 w-4 mr-2" />
              Exportar con Plantilla
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  )
}
