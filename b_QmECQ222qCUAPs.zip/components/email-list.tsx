'use client'

import { useMemo, useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Badge } from '@/components/ui/badge'
import { EmailCard } from '@/components/email-card'
import { EMAIL_PROVIDERS, EXPORT_TEMPLATES, ALL_TEMPLATES, EmailAccount, useEmailStore } from '@/lib/store'
import { 
  CheckSquare, 
  Search, 
  Trash2, 
  XSquare, 
  Dumbbell, 
  Mail, 
  MoreVertical,
  Download,
  FileText,
  FileSpreadsheet,
  Image,
  Sparkles,
  Zap
} from 'lucide-react'
import jsPDF from 'jspdf'

interface EmailListProps {
  onEditAccount: (account: EmailAccount) => void
}

interface Template {
  id: string
  name: string
  description: string
  colors: string[]
}

export function EmailList({ onEditAccount }: EmailListProps) {
  const {
    accounts,
    searchQuery,
    setSearchQuery,
    filterProvider,
    setFilterProvider,
    selectedIds,
    selectAll,
    selectOne,
    clearSelection,
    deleteSelected,
    toggleSelect,
    settings,
    exportSelected,
  } = useEmailStore()

  const [templatesOpen, setTemplatesOpen] = useState(false)
  const [selectedCategory, setSelectedCategory] = useState('all')
  const [templateSearch, setTemplateSearch] = useState('')

  const filteredAccounts = useMemo(() => {
    return accounts.filter((account) => {
      const matchesSearch =
        account.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
        account.notes?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        account.tags.some((tag) => tag.toLowerCase().includes(searchQuery.toLowerCase()))

      const matchesProvider = filterProvider === 'all' || account.provider === filterProvider

      return matchesSearch && matchesProvider
    })
  }, [accounts, searchQuery, filterProvider])

  const hasSelection = selectedIds.length > 0
  const allSelected = selectedIds.length === accounts.length && accounts.length > 0
  const someSelected = selectedIds.length > 0 && selectedIds.length < accounts.length

  const getDataToExport = (): EmailAccount[] => {
    if (selectedIds.length > 0) {
      return exportSelected()
    }
    return accounts
  }

  const handleExportJSON = () => {
    const data = getDataToExport()
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `gymmail-vault-${selectedIds.length > 0 ? 'seleccionados' : 'todos'}-${new Date().toISOString().split('T')[0]}.json`
    a.click()
    URL.revokeObjectURL(url)
  }

  const handleExportPDF = (template?: Template) => {
    const doc = new jsPDF()
    const data = getDataToExport()
    
    const colors = template?.colors || ['#0a0a0a', '#00ff41', '#ffffff', '#39ff14']

    doc.setFillColor(colors[0])
    doc.rect(0, 0, 210, 40, 'F')
    
    doc.setFontSize(24)
    doc.setTextColor(colors[1])
    doc.text(settings.appName, 20, 25)

    doc.setFontSize(10)
    doc.setTextColor(colors[2])
    doc.text(`Exportado: ${new Date().toLocaleString()}`, 20, 33)
    doc.text(`Total: ${data.length} cuenta${data.length !== 1 ? 's' : ''}`, 120, 33)
    if (template) {
      doc.text(`Plantilla: ${template.name}`, 20, 38)
    }

    let yPos = 50
    const pageHeight = 280

    data.forEach((account, index) => {
      if (yPos > pageHeight) {
        doc.addPage()
        doc.setFillColor(colors[0])
        doc.rect(0, 0, 210, 15, 'F')
        doc.setFontSize(10)
        doc.setTextColor(colors[1])
        doc.text(settings.appName, 20, 10)
        yPos = 25
      }

      doc.setFillColor(colors[0])
      doc.roundedRect(15, yPos - 5, 180, 28, 3, 3, 'F')

      doc.setFontSize(12)
      doc.setTextColor(colors[1])
      doc.text(`${index + 1}. ${account.email}`, 20, yPos + 3)

      doc.setFontSize(9)
      doc.setTextColor(colors[2])
      doc.text(`Proveedor: ${account.provider}`, 25, yPos + 10)
      doc.text(`Contrasena: ${account.password}`, 100, yPos + 10)
      
      if (account.phone) {
        doc.text(`Tel: ${account.phone}`, 25, yPos + 17)
      }
      if (account.tags.length) {
        doc.text(`Tags: ${account.tags.join(', ')}`, 100, yPos + 17)
      }

      yPos += 35
    })

    doc.setFontSize(8)
    doc.setTextColor(150, 150, 150)
    doc.text('Generado con GymMail Vault', 20, 290)

    doc.save(`gymmail-vault-${template?.id || 'default'}-${selectedIds.length > 0 ? 'seleccionados' : 'todos'}.pdf`)
    setTemplatesOpen(false)
  }

  const handleExportCSV = () => {
    const data = getDataToExport()
    const headers = ['Email', 'Contrasena', 'Proveedor', 'Telefono', 'Correo Recuperacion', 'Etiquetas', 'Notas']
    const rows = data.map((acc) => [
      acc.email,
      acc.password,
      acc.provider,
      acc.phone || '',
      acc.recoveryEmail || '',
      acc.tags.join('; '),
      acc.notes || '',
    ])

    const csv = [headers.join(','), ...rows.map((r) => r.map((c) => `"${c}"`).join(','))].join('\n')
    const blob = new Blob([csv], { type: 'text/csv' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `gymmail-vault-${selectedIds.length > 0 ? 'seleccionados' : 'todos'}-${new Date().toISOString().split('T')[0]}.csv`
    a.click()
    URL.revokeObjectURL(url)
  }

  const handleExportPNG = async () => {
    const data = getDataToExport()
    
    // Create canvas
    const canvas = document.createElement('canvas')
    const ctx = canvas.getContext('2d')
    if (!ctx) return

    const width = 800
    const rowHeight = 80
    const headerHeight = 100
    const height = headerHeight + (data.length * rowHeight) + 50
    
    canvas.width = width
    canvas.height = height

    // Background
    ctx.fillStyle = '#0a0a0a'
    ctx.fillRect(0, 0, width, height)

    // Header
    ctx.fillStyle = '#00ff41'
    ctx.font = 'bold 32px Arial'
    ctx.fillText(settings.appName, 30, 50)
    
    ctx.fillStyle = '#888888'
    ctx.font = '14px Arial'
    ctx.fillText(`${data.length} cuenta${data.length !== 1 ? 's' : ''} | ${new Date().toLocaleDateString()}`, 30, 75)

    // Cards
    data.forEach((account, index) => {
      const y = headerHeight + (index * rowHeight)
      
      // Card background
      ctx.fillStyle = '#1a1a1a'
      ctx.beginPath()
      ctx.roundRect(20, y, width - 40, rowHeight - 10, 8)
      ctx.fill()

      // Email
      ctx.fillStyle = '#00ff41'
      ctx.font = 'bold 16px Arial'
      ctx.fillText(`${index + 1}. ${account.email}`, 35, y + 25)

      // Details
      ctx.fillStyle = '#cccccc'
      ctx.font = '12px Arial'
      ctx.fillText(`Proveedor: ${account.provider}`, 35, y + 45)
      ctx.fillText(`Contrasena: ${account.password}`, 250, y + 45)
      
      if (account.phone) {
        ctx.fillText(`Tel: ${account.phone}`, 35, y + 62)
      }
    })

    // Footer
    ctx.fillStyle = '#666666'
    ctx.font = '10px Arial'
    ctx.fillText('Generado con GymMail Vault', 30, height - 20)

    // Download
    const link = document.createElement('a')
    link.download = `gymmail-vault-${selectedIds.length > 0 ? 'seleccionados' : 'todos'}.png`
    link.href = canvas.toDataURL('image/png')
    link.click()
  }

  const filteredTemplates = ALL_TEMPLATES.filter(t => {
    const matchesSearch = t.name.toLowerCase().includes(templateSearch.toLowerCase()) ||
                         t.description.toLowerCase().includes(templateSearch.toLowerCase())
    
    if (selectedCategory === 'all') return matchesSearch
    
    const categoryTemplates = EXPORT_TEMPLATES[selectedCategory as keyof typeof EXPORT_TEMPLATES] || []
    return matchesSearch && categoryTemplates.some(ct => ct.id === t.id)
  })

  const templateCategories = [
    { id: 'all', name: 'Todas', count: ALL_TEMPLATES.length },
    { id: 'gym', name: 'Gym', count: EXPORT_TEMPLATES.gym.length },
    { id: 'profesional', name: 'Pro', count: EXPORT_TEMPLATES.profesional.length },
    { id: 'tech', name: 'Tech', count: EXPORT_TEMPLATES.tech.length },
    { id: 'gaming', name: 'Gaming', count: EXPORT_TEMPLATES.gaming.length },
    { id: 'social', name: 'Social', count: EXPORT_TEMPLATES.social.length },
  ]

  return (
    <div className="space-y-4">
      {/* Search and Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-primary/60" />
          <Input
            placeholder="Buscar correos, etiquetas..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-11 h-12 bg-input border-primary/20 focus:border-primary text-lg"
          />
        </div>
        <Select value={filterProvider} onValueChange={setFilterProvider}>
          <SelectTrigger className="w-full sm:w-48 h-12 bg-input border-primary/20">
            <SelectValue placeholder="Todos los proveedores" />
          </SelectTrigger>
          <SelectContent className="gym-card border-primary/30">
            <SelectItem value="all">Todos los proveedores</SelectItem>
            {EMAIL_PROVIDERS.map((provider) => (
              <SelectItem key={provider} value={provider}>
                {provider}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Selection Actions */}
      {accounts.length > 0 && (
        <div className="flex flex-wrap items-center justify-between gap-3 py-3 px-4 rounded-xl bg-gradient-to-r from-secondary/50 to-secondary/30 border border-primary/20">
          <div className="flex flex-wrap items-center gap-2">
            {/* Selection buttons */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="outline"
                  size="sm"
                  className="border-primary/30 hover:bg-primary/10"
                >
                  <CheckSquare className="h-4 w-4 mr-2" />
                  Seleccionar
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="gym-card border-primary/30">
                <DropdownMenuItem onClick={selectAll}>
                  <CheckSquare className="h-4 w-4 mr-2" />
                  Seleccionar todo ({accounts.length})
                </DropdownMenuItem>
                {filteredAccounts.length > 0 && filteredAccounts.length !== accounts.length && (
                  <DropdownMenuItem onClick={() => {
                    filteredAccounts.forEach(acc => {
                      if (!selectedIds.includes(acc.id)) {
                        toggleSelect(acc.id)
                      }
                    })
                  }}>
                    <CheckSquare className="h-4 w-4 mr-2" />
                    Seleccionar filtrados ({filteredAccounts.length})
                  </DropdownMenuItem>
                )}
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={clearSelection} disabled={!hasSelection}>
                  <XSquare className="h-4 w-4 mr-2" />
                  Deseleccionar todo
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            {hasSelection && (
              <Badge variant="outline" className="gym-badge px-3 py-1">
                {selectedIds.length} seleccionado{selectedIds.length > 1 ? 's' : ''}
              </Badge>
            )}
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {/* Export dropdown */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="outline"
                  size="sm"
                  className="border-primary/30 hover:bg-primary/10"
                >
                  <Download className="h-4 w-4 mr-2" />
                  Exportar {hasSelection ? `(${selectedIds.length})` : `(${accounts.length})`}
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="gym-card border-primary/30 w-56">
                <div className="px-2 py-1.5 text-xs text-muted-foreground">
                  {hasSelection ? `Exportar ${selectedIds.length} seleccionados` : `Exportar todos (${accounts.length})`}
                </div>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleExportJSON}>
                  <FileText className="h-4 w-4 mr-2 text-blue-500" />
                  Exportar JSON
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => handleExportPDF()}>
                  <FileText className="h-4 w-4 mr-2 text-red-500" />
                  Exportar PDF (Default)
                </DropdownMenuItem>
                <DropdownMenuItem onClick={handleExportCSV}>
                  <FileSpreadsheet className="h-4 w-4 mr-2 text-green-500" />
                  Exportar CSV
                </DropdownMenuItem>
                <DropdownMenuItem onClick={handleExportPNG}>
                  <Image className="h-4 w-4 mr-2 text-purple-500" />
                  Exportar PNG
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => setTemplatesOpen(true)}>
                  <Sparkles className="h-4 w-4 mr-2 text-primary" />
                  PDF con Plantilla (1000+)
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            {/* Delete button */}
            {hasSelection && (
              <Button 
                variant="destructive" 
                size="sm" 
                onClick={deleteSelected}
                className="shadow-lg"
              >
                <Trash2 className="h-4 w-4 mr-2" />
                Eliminar ({selectedIds.length})
              </Button>
            )}
          </div>
        </div>
      )}

      {/* Email Cards */}
      <div className="space-y-3">
        {filteredAccounts.length > 0 ? (
          filteredAccounts.map((account) => (
            <EmailCard key={account.id} account={account} onEdit={onEditAccount} />
          ))
        ) : (
          <div className="text-center py-20 px-4">
            <div className="inline-flex items-center justify-center w-24 h-24 rounded-2xl bg-gradient-to-br from-primary/20 to-accent/20 mb-6 animate-pulse-glow">
              {searchQuery || filterProvider !== 'all' ? (
                <Search className="h-12 w-12 text-primary" />
              ) : (
                <Mail className="h-12 w-12 text-primary" />
              )}
            </div>
            <h3 className="text-2xl font-bold text-foreground mb-2 neon-text">
              {searchQuery || filterProvider !== 'all' ? 'Sin resultados' : 'Sin correos'}
            </h3>
            <p className="text-muted-foreground max-w-md mx-auto">
              {searchQuery || filterProvider !== 'all'
                ? 'No se encontraron correos con esos filtros. Intenta con otros terminos.'
                : 'Agrega tu primer correo para comenzar a organizar tus cuentas de forma segura.'}
            </p>
            {!searchQuery && filterProvider === 'all' && (
              <div className="mt-8 flex items-center justify-center gap-2 text-primary/50">
                <Dumbbell className="h-5 w-5" />
                <span className="text-sm">Tu boveda esta lista para entrenar</span>
                <Dumbbell className="h-5 w-5" />
              </div>
            )}
          </div>
        )}
      </div>

      {/* Stats Footer */}
      {filteredAccounts.length > 0 && (
        <div className="text-center text-sm text-muted-foreground pt-6 border-t border-primary/10">
          <span className="text-primary font-semibold">{filteredAccounts.length}</span> de{' '}
          <span className="text-primary font-semibold">{accounts.length}</span> correos
        </div>
      )}

      {/* Templates Dialog */}
      <Dialog open={templatesOpen} onOpenChange={setTemplatesOpen}>
        <DialogContent className="max-w-4xl max-h-[85vh] overflow-hidden gym-card border-primary/30">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 neon-text">
              <Sparkles className="h-5 w-5 text-primary" />
              1000 Plantillas de Exportacion
            </DialogTitle>
            <DialogDescription>
              Exportar {hasSelection ? `${selectedIds.length} seleccionados` : `todos (${accounts.length})`} con una plantilla personalizada
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            {/* Search */}
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Buscar plantillas..."
                value={templateSearch}
                onChange={(e) => setTemplateSearch(e.target.value)}
                className="pl-10 bg-input border-primary/20"
              />
            </div>

            {/* Categories */}
            <div className="flex flex-wrap gap-2">
              {templateCategories.map((cat) => (
                <Button
                  key={cat.id}
                  variant={selectedCategory === cat.id ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setSelectedCategory(cat.id)}
                  className={selectedCategory === cat.id ? 'gym-button' : 'border-primary/30'}
                >
                  {cat.name}
                  <Badge variant="secondary" className="ml-2 text-xs">
                    {cat.count}
                  </Badge>
                </Button>
              ))}
            </div>

            {/* Templates Grid */}
            <ScrollArea className="h-[50vh]">
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3 pr-4">
                {filteredTemplates.slice(0, 100).map((template) => (
                  <div
                    key={template.id}
                    onClick={() => handleExportPDF(template)}
                    className="p-3 rounded-lg border border-primary/20 hover:border-primary/60 cursor-pointer transition-all hover:scale-[1.02] bg-secondary/30"
                  >
                    <div className="flex gap-1 mb-2">
                      {template.colors.map((color, i) => (
                        <div
                          key={i}
                          className="w-4 h-4 rounded-full border border-white/20"
                          style={{ backgroundColor: color }}
                        />
                      ))}
                    </div>
                    <p className="text-sm font-medium truncate">{template.name}</p>
                    <p className="text-xs text-muted-foreground truncate">{template.description}</p>
                  </div>
                ))}
              </div>
              {filteredTemplates.length > 100 && (
                <p className="text-center text-sm text-muted-foreground mt-4">
                  Mostrando 100 de {filteredTemplates.length} plantillas. Usa el buscador para encontrar mas.
                </p>
              )}
            </ScrollArea>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
