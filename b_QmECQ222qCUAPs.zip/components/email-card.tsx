'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Checkbox } from '@/components/ui/checkbox'
import { Badge } from '@/components/ui/badge'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { EmailAccount, useEmailStore } from '@/lib/store'
import { Copy, Edit, Eye, EyeOff, MoreVertical, Trash2, Check } from 'lucide-react'

interface EmailCardProps {
  account: EmailAccount
  onEdit: (account: EmailAccount) => void
}

export function EmailCard({ account, onEdit }: EmailCardProps) {
  const [showPassword, setShowPassword] = useState(false)
  const [copied, setCopied] = useState<string | null>(null)
  const { toggleSelect, selectedIds, deleteAccount } = useEmailStore()

  const isSelected = selectedIds.includes(account.id)

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text)
    setCopied(label)
    setTimeout(() => setCopied(null), 2000)
  }

  const getProviderColor = (provider: string) => {
    const colors: Record<string, string> = {
      Gmail: 'bg-red-500/20 text-red-400 border-red-500/40',
      Hotmail: 'bg-blue-500/20 text-blue-400 border-blue-500/40',
      Outlook: 'bg-blue-600/20 text-blue-300 border-blue-600/40',
      Yahoo: 'bg-purple-500/20 text-purple-400 border-purple-500/40',
      iCloud: 'bg-slate-400/20 text-slate-300 border-slate-400/40',
      ProtonMail: 'bg-violet-500/20 text-violet-400 border-violet-500/40',
      AOL: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/40',
      Zoho: 'bg-green-500/20 text-green-400 border-green-500/40',
    }
    return colors[provider] || 'bg-primary/20 text-primary border-primary/40'
  }

  return (
    <div className={`gym-card group transition-all duration-300 rounded-xl p-4 ${
      isSelected 
        ? 'border-primary bg-primary/10 shadow-[0_0_20px_rgba(0,255,65,0.2)]' 
        : 'border-border hover:border-primary/50'
    }`}>
      <div className="flex items-start gap-4">
        {/* Checkbox */}
        <Checkbox
          checked={isSelected}
          onCheckedChange={() => toggleSelect(account.id)}
          className="mt-1 border-primary/50 data-[state=checked]:bg-primary data-[state=checked]:border-primary"
        />

        {/* Avatar/Image */}
        <div className="relative shrink-0">
          {account.image ? (
            <img
              src={account.image}
              alt={account.email}
              className="w-14 h-14 rounded-xl object-cover border-2 border-primary/30"
            />
          ) : (
            <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-primary/40 to-accent/40 flex items-center justify-center border-2 border-primary/30">
              <span className="text-xl font-bold text-foreground">
                {account.email.charAt(0).toUpperCase()}
              </span>
            </div>
          )}
          <div className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-primary border-2 border-card flex items-center justify-center">
            <Check className="h-3 w-3 text-primary-foreground" />
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1 flex-wrap">
            <Badge variant="outline" className={`${getProviderColor(account.provider)} font-semibold`}>
              {account.provider}
            </Badge>
            {account.tags.slice(0, 2).map((tag) => (
              <Badge key={tag} className="gym-badge text-xs">
                {tag}
              </Badge>
            ))}
            {account.tags.length > 2 && (
              <Badge variant="secondary" className="text-xs">
                +{account.tags.length - 2}
              </Badge>
            )}
          </div>

          <h3 className="font-semibold text-foreground truncate text-lg">{account.email}</h3>

          <div className="flex items-center gap-2 mt-2">
            <code className="text-sm text-muted-foreground font-mono bg-secondary/50 px-2 py-1 rounded">
              {showPassword ? account.password : '••••••••••'}
            </code>
            <Button
              variant="ghost"
              size="icon"
              className="h-7 w-7 hover:bg-primary/20 hover:text-primary"
              onClick={() => setShowPassword(!showPassword)}
            >
              {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="h-7 w-7 hover:bg-primary/20 hover:text-primary"
              onClick={() => copyToClipboard(account.password, 'password')}
            >
              {copied === 'password' ? <Check className="h-4 w-4 text-primary" /> : <Copy className="h-4 w-4" />}
            </Button>
          </div>

          {account.phone && (
            <p className="text-sm text-muted-foreground mt-2 flex items-center gap-2">
              <span className="text-primary">Tel:</span> {account.phone}
            </p>
          )}

          {account.notes && (
            <p className="text-sm text-muted-foreground mt-1 line-clamp-2 italic">{account.notes}</p>
          )}
        </div>

        {/* Actions */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button 
              variant="ghost" 
              size="icon" 
              className="opacity-0 group-hover:opacity-100 transition-opacity hover:bg-primary/20"
            >
              <MoreVertical className="h-5 w-5" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="gym-card border-primary/30">
            <DropdownMenuItem 
              onClick={() => copyToClipboard(account.email, 'email')}
              className="focus:bg-primary/20"
            >
              <Copy className="mr-2 h-4 w-4" />
              Copiar correo
              {copied === 'email' && <Check className="ml-auto h-4 w-4 text-primary" />}
            </DropdownMenuItem>
            <DropdownMenuItem 
              onClick={() => copyToClipboard(account.password, 'password')}
              className="focus:bg-primary/20"
            >
              <Copy className="mr-2 h-4 w-4" />
              Copiar contrasena
              {copied === 'password' && <Check className="ml-auto h-4 w-4 text-primary" />}
            </DropdownMenuItem>
            <DropdownMenuItem 
              onClick={() => onEdit(account)}
              className="focus:bg-primary/20"
            >
              <Edit className="mr-2 h-4 w-4" />
              Editar
            </DropdownMenuItem>
            <DropdownMenuItem
              onClick={() => deleteAccount(account.id)}
              className="text-destructive focus:text-destructive focus:bg-destructive/20"
            >
              <Trash2 className="mr-2 h-4 w-4" />
              Eliminar
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </div>
  )
}
