'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { useEmailStore } from '@/lib/store'
import { Lock, Dumbbell, Eye, EyeOff, ShieldCheck, AlertTriangle } from 'lucide-react'

export function LockScreen() {
  const [password, setPassword] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const [error, setError] = useState('')
  const [attempts, setAttempts] = useState(0)
  const [isShaking, setIsShaking] = useState(false)
  
  const { settings, unlockApp } = useEmailStore()

  const handleUnlock = () => {
    if (password === settings.appPassword) {
      unlockApp()
      setPassword('')
      setError('')
      setAttempts(0)
    } else {
      setAttempts(prev => prev + 1)
      setError(`Contrasena incorrecta. Intento ${attempts + 1}/5`)
      setIsShaking(true)
      setTimeout(() => setIsShaking(false), 500)
      setPassword('')
    }
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleUnlock()
    }
  }

  return (
    <div className="min-h-screen bg-background gym-pattern flex items-center justify-center p-4">
      {/* Floating Elements Background */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        {[...Array(8)].map((_, i) => (
          <div
            key={i}
            className="absolute animate-float opacity-10"
            style={{
              left: `${10 + (i * 12)}%`,
              top: `${15 + (i % 3) * 25}%`,
              animationDelay: `${i * 0.5}s`,
              animationDuration: `${4 + (i % 3)}s`
            }}
          >
            <Dumbbell className="h-12 w-12 text-primary" />
          </div>
        ))}
      </div>

      <div className={`w-full max-w-md ${isShaking ? 'animate-shake' : ''}`}>
        {/* Lock Icon */}
        <div className="flex justify-center mb-8">
          <div className="relative">
            <div className="w-24 h-24 rounded-full bg-gradient-to-br from-primary/30 to-accent/30 flex items-center justify-center animate-pulse-glow">
              <Lock className="h-12 w-12 text-primary" />
            </div>
            <div className="absolute -bottom-2 -right-2 w-8 h-8 rounded-full bg-card border-2 border-primary flex items-center justify-center">
              <ShieldCheck className="h-4 w-4 text-primary" />
            </div>
          </div>
        </div>

        {/* Title */}
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-foreground neon-text mb-2">
            {settings.appName}
          </h1>
          <p className="text-muted-foreground">
            Ingresa tu contrasena para acceder
          </p>
        </div>

        {/* Password Input */}
        <div className="gym-card rounded-xl p-6 space-y-4">
          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground">Contrasena</label>
            <div className="relative">
              <Input
                type={showPassword ? 'text' : 'password'}
                placeholder="Ingresa tu contrasena"
                value={password}
                onChange={(e) => {
                  setPassword(e.target.value)
                  setError('')
                }}
                onKeyDown={handleKeyDown}
                className="pr-10 h-12 text-lg bg-input border-border focus:border-primary"
                autoFocus
              />
              <Button
                type="button"
                variant="ghost"
                size="icon"
                className="absolute right-1 top-1/2 -translate-y-1/2 h-8 w-8"
                onClick={() => setShowPassword(!showPassword)}
              >
                {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </Button>
            </div>
          </div>

          {error && (
            <div className="flex items-center gap-2 text-destructive text-sm p-3 rounded-lg bg-destructive/10 border border-destructive/30">
              <AlertTriangle className="h-4 w-4" />
              {error}
            </div>
          )}

          <Button
            onClick={handleUnlock}
            disabled={!password || attempts >= 5}
            className="w-full h-12 text-lg gym-button"
          >
            <Lock className="h-5 w-5 mr-2" />
            {attempts >= 5 ? 'Bloqueado' : 'Desbloquear'}
          </Button>

          {attempts >= 5 && (
            <p className="text-center text-sm text-destructive">
              Demasiados intentos. Por favor, recarga la pagina.
            </p>
          )}
        </div>

        {/* Footer */}
        <div className="mt-6 text-center">
          <p className="text-xs text-muted-foreground">
            Tu boveda esta protegida con contrasena
          </p>
        </div>
      </div>

      <style jsx>{`
        @keyframes shake {
          0%, 100% { transform: translateX(0); }
          10%, 30%, 50%, 70%, 90% { transform: translateX(-5px); }
          20%, 40%, 60%, 80% { transform: translateX(5px); }
        }
        .animate-shake {
          animation: shake 0.5s ease-in-out;
        }
      `}</style>
    </div>
  )
}
